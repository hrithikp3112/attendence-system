window.onload = initAll;

function initAll(){
	//task1
	getAllElements();	

	//task2
	setAllActions();	
}

function setAllActions(){
	collectUnivBranches();
	collectCollegeBranches();
	btn.onclick = saveBranch;
}

var branch,btn;
var a;
function getAllElements(){
	branch = document.getElementById('sel_records');
	btn = document.getElementById('btn');
	a = document.getElementById('a');
}

var reqCB;
function collectCollegeBranches(){
	reqCB = new XMLHttpRequest();

	reqCB.open('get','collect_college_branches.do',true);
	reqCB.onreadystatechange = showCollegeBranches;
	reqCB.send(null);
}

var img;
function showCollegeBranches(){
	if(reqCB.readyState==4&&reqCB.status==200){
		var resp = eval(reqCB.responseText);
		
		a.innerHTML = '';

		for(i=0;i<resp.length;i++){
			var str = resp[i].branch.substring(0,25)+'...';
			
			var dv = document.createElement('div');
			dv.innerHTML = str;
			dv.className = '_record';
			dv.title = resp[i].branch;			
			
			img = document.createElement('img');
			img.src = 'images/cancel.png';
			img.className = 'cancel';
			img.onclick = deleteRecord;
			img.branch_index = resp[i].branchId;
			img.prt = dv;
			
			dv.appendChild(img);

			a.appendChild(dv);
		}
	}
}

var delReq = null;
var curRecord;
function deleteRecord(){
	curRecord = this;

	delReq = new XMLHttpRequest();
	delReq.open('get','delete_branch.do?branch_id='+this.branch_index,false);
	delReq.onreadystatechange = afterBranchDeletion;
	delReq.send(null);
}

function afterBranchDeletion(){
	if(delReq.readyState==4&&delReq.status==200){
		var resp = delReq.responseText;

		if(resp=='success'){
			a.removeChild(curRecord.prt);
		}else if(resp=='fail'){
		
		}
	}
}

var saveReq;
function saveBranch(){
	saveReq = new XMLHttpRequest();
	saveReq.open('get','save_branch.do?branch_id='+branch.value,true);
	saveReq.onreadystatechange = afterSaveBranch;
	saveReq.send(null);
}


function afterSaveBranch(){
	if(saveReq.readyState==4&&saveReq.status==200){
		var str = saveReq.responseText;

		if(str=='success'){
			collectCollegeBranches();
		}else if(str=='fail'){
			//?
		}else{
			window.location = 'index.jsp';
		}
	}
}






var unv_brn_req = null;
function collectUnivBranches(){
	unv_brn_req = new XMLHttpRequest();

	unv_brn_req.open('get','collect_univ_branches.do',true);
	unv_brn_req.onreadystatechange = showUnivBranches;
	unv_brn_req.send(null);
}


function showUnivBranches(){
	if(unv_brn_req.readyState==4&&unv_brn_req.status==200){
		var result = unv_brn_req.responseText;
		

		var branches = eval(result);
		
		for(i=0;i<branches.length;i++){
			var opt = document.createElement('option');
			opt.text = branches[i].branch;
			opt.value = branches[i].branchId;

			branch.appendChild(opt);
		}
	}
}

















