window.onload = initAll;

function initAll(){
	getAllElements();

	setAllActions();
}

var sel_records,btn,a;
function getAllElements(){
	sel_records = document.getElementById('sel_records');
	a = document.getElementById('a');
	btn = document.getElementById('btn');
}

function setAllActions(){
	collectAllBatches();
	collectCollegeBatches();
	btn.onclick = saveBatch;
}

var reqBC;
function collectCollegeBatches(){
	reqBC = new XMLHttpRequest();
	reqBC.open('get','collect_college_batches.do',true);
	reqBC.onreadystatechange = showCollegeBatches;
	reqBC.send(null);
}


function showCollegeBatches(){
	if(reqBC.readyState==4&&reqBC.status==200){
		var resp = eval(reqBC.responseText);
		
		a.innerHTML = '';
		for(i=0;i<resp.length;i++){
			var dv = document.createElement('div');

			dv.className = '_record';
			dv.innerHTML = resp[i].startYear+'-'+resp[i].endYear;

			var img = document.createElement('img');
			img.className = 'cancel';
			img.onclick = deleteRecord;
			img.src = 'images/cancel.png';

			img.prt = dv;

			dv.appendChild(img);
			a.appendChild(dv);
		}
	}
}

function deleteRecord(){
	
}

var svBatchReq = null;
function saveBatch(){
	svBatchReq = new XMLHttpRequest();

	svBatchReq.open('get','save_college_batch.do?batch_id='+sel_records.value,true);
	svBatchReq.onreadystatechange = afterBatchSave;
	svBatchReq.send(null);
}

function afterBatchSave(){
	if(svBatchReq.readyState==4&&svBatchReq.status==200){
		var resp = svBatchReq.responseText;
		
		a
		if(resp=='success'){
			collectCollegeBatches();
		}else if(resp=='fail'){
		
		}else{
			window.location = 'college.jsp';
		}
	}
}

var batch_req;
function collectAllBatches(){
	batch_req = new XMLHttpRequest();

	batch_req.open('get','collect_batches.do',true);
	batch_req.onreadystatechange = showRecords;
	batch_req.send(null);
}

function showRecords(){
	if(batch_req.readyState==4&&batch_req.status==200){
		var resp = eval(batch_req.responseText);
		//alert(batch_req.responseText)
		
		
		for(i=0;i<resp.length;i++){
			var opt = document.createElement('option');
			
			opt.text = resp[i].startYear+'-'+resp[i].endYear;
			opt.value = resp[i].batchId;	

			sel_records.appendChild(opt);
		}
	}
}