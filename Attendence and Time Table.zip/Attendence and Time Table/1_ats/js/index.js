window.onload = initAll;

function initAll(){
	getAllElements();

	setAllActions();
}

var clg_btn,fclt_btn;
function getAllElements(){
	clg_btn = document.getElementById('clg_btn');
	fclt_btn = document.getElementById('fclt_btn');
}

function setAllActions(){
	clg_btn.onclick = function(){ window.location = 'college.jsp' };
	fclt_btn.onclick = function(){ window.location = 'faculty.do'}
}
