function logout(){
	window.location = "logout.do";
}