window.onload = initAll;

function initAll(){
	getAllElements();

	setAllActions();
}

var branch = null;
function getAllElements(){
	branch = document.getElementById('branch');
}

function setAllActions(){
	collectCollegeBranches();
}


var reqCB;
function collectCollegeBranches(){
	reqCB = new XMLHttpRequest();

	reqCB.open('get','collect_college_branches.do',true);
	reqCB.onreadystatechange = showCollegeBranches;
	reqCB.send(null);
}

var img;
function showCollegeBranches(){
	if(reqCB.readyState==4&&reqCB.status==200){
		var resp = eval(reqCB.responseText);
		
		if(resp.length>0){
			branch.innerHTML = '<option value="0">Select</option>';
		}

		for(i=0;i<resp.length;i++){
			var str = resp[i].branch.substring(0,15)+'...';
			
			var opt = document.createElement('option');

			opt.text = str;
			opt.title = resp[i].branch;
			opt.value = resp[i].branchId;
			
			branch.appendChild(opt);
		}
	}
}