var branch_menu = document.getElementById('branch_menu');
var batch_menu = document.getElementById('batch_menu');
var faculty_menu = document.getElementById('faculty_menu');

branch_menu.onclick = function(){ window.location = 'college_branch.jsp'; };
batch_menu.onclick = function(){ window.location = 'college_batch.do'; };
faculty_menu.onclick = function(){ window.location = 'faculty.do'; };