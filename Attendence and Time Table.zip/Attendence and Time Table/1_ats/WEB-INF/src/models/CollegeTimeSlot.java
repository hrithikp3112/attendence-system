package models;
import java.sql.*;

public class CollegeTimeSlot{
	private Integer collegeTimeSlotId;
	private College college;
	private Time startTime;
	private Time endTime;
	
//###############################################
	public void setCollegeTimeSlotId(Integer collegeTimeSlotId){
		this.collegeTimeSlotId = collegeTimeSlotId;
	}

	public Integer getCollegeTimeSlotId(){
		return collegeTimeSlotId;
	}

//###############################################
	public void setCollege(College college){
		this.college = college;
	}
	public College getCollege(){
		return college;
	}

//###############################################
	public void setStartTime(Time startTime){
		this.startTime = startTime;
	}
	public Time getStartTime(){
		return startTime;
	}

//###############################################
	public void setEndTime(Time endTime){
		this.endTime = endTime;
	}
	public Time getEndTime(){
		return endTime;
	}

}