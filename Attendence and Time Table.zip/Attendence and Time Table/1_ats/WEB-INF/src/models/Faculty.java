package models;
import java.sql.*;

public class Faculty{
	private Integer facultyId;
	private String facultyName;
	private String picPath;
	private String fathersName;
	private Date dob;
	private Branch branch;
	private String contact;
	private String address;
	private String qualification;
	private Integer experience;
	private String email;
	private String password;
	private Designation designation;
	private College college;

//#######################################################
	public void setFacultyId(Integer facultyId){
		this.facultyId = facultyId;
	}

	public Integer getFacultyId(){
		return facultyId;
	}

//#######################################################
	public void setFacultyName(String facultyName){
		this.facultyName = facultyName;
	}

	public String getFacultyName(){
		return facultyName;
	}

//#######################################################
	public void setPicPath(String picPath){
		this.picPath = picPath;
	}

	public String getPicPath(){
		return picPath;
	}

//#######################################################
	public void setFathersName(String fathersName){
		this.fathersName = fathersName;
	}

	public String getFathersName(){
		return fathersName;
	}

//#######################################################
	public void setDob(Date dob){
		this.dob = dob;
	}

	public Date getDob(){
		return dob;
	}

//#######################################################
	public void setBranch(Branch branch){
		this.branch = branch;
	}

	public Branch getBranch(){
		return branch;
	}

//#######################################################
	public void setContact(String contact){
		this.contact = contact;
	}

	public String getContact(){
		return contact;
	}

//#######################################################

	public void setAddress(String address){
		this.address = address;
	}

	public String getAddress(){
		return address;
	}

//#######################################################

	public void setQualification(String qualification){
		this.qualification = qualification;
	}

	public String getQualification(){
		return qualification;
	}

//#######################################################
	public void setExperience(Integer experience){
		this.experience = experience;
	}

	public Integer getExperience(){
		return experience;
	}

//#######################################################
	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

//#######################################################
	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return password;
	}

//#######################################################
	public void setDesignation(Designation designation){
		this.designation = designation;
	}

	public Designation getDesignation(){
		return designation;
	}

//#######################################################
	public void setCollege(College college){
		this.college = college;
	}

	public College getCollege(){
		return college;
	}
}	
