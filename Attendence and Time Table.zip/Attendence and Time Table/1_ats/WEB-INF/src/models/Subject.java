package models;

public class Subject{
	private Integer subjectId;
	private String subject;

 //##################################################################
	public void setSubjectId(Integer subjectId){
		this.subjectId = subjectId;
	}

	public Integer getSubjectId(){
		return subjectId;
	}

//##################################################################
	public void setSubject(String subject){
		this.subject = subject;
	}

	public String getSubject(){
		return subject;
	}

}