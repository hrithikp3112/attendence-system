package models;

public class Semester{
	private Integer semesterId;
	private String semester;

//##################################################################
	public void setSemesterId(Integer semesterId){
		this.semesterId = semesterId;
	}

	public Integer getSemesterId(){
		return semesterId;
	}

//##################################################################
	public void setSemester(String semester){
		this.semester = semester;
	}

	public String getSemester(){
		return semester;
	}

}