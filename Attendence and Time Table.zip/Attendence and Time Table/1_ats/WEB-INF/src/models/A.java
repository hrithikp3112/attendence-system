import java.util.Random;

class A{
	public static void main(String[] args){
		for(int i=0;i<20;i++)
			System.out.println((int)Math.floor(new Random().nextDouble()*1000000)+"_"+new java.util.Date().getTime());

	}
}