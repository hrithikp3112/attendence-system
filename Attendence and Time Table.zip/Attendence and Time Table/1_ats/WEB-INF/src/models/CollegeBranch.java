package models;

import java.sql.*;

public class CollegeBranch{
	private Integer collegeBranchId;
	private College college;
	private Branch branch;

	public CollegeBranch(){
	
	}

	public CollegeBranch(College college,Branch branch){
		this.college = college;
		this.branch = branch;
	}

	public void setBranch(Branch branch){
		this.branch = branch;
	}

	public Branch getBranch(){
		return branch;
	}

	public void setCollege(College college){
		this.college = college;
	}


	public boolean deleteCollegeBranch(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String query = "delete from college_branches where college_id=? and branch_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1,college.getCollegeId());
			ps.setInt(2,branch.getBranchId());

			int val = ps.executeUpdate();
			
			if(val!=0){
				flag = true;
			}

			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return flag;
	}

	public boolean saveCollegeBranch(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select college_branch_id from college_branches where college_id=? and branch_id=?";
			PreparedStatement p1 = con.prepareStatement(q1);
			p1.setInt(1,college.getCollegeId());
			p1.setInt(2,branch.getBranchId());
			ResultSet r1 = p1.executeQuery();
			if(!r1.next()){
				String query = "insert into college_branches (college_id,branch_id) value (?,?)";
				PreparedStatement ps = con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
				ps.setInt(1,college.getCollegeId());
				ps.setInt(2,branch.getBranchId());

				ps.executeUpdate();

				ResultSet rs = ps.getGeneratedKeys();
				if(rs.next()){
					collegeBranchId = rs.getInt(1);
					flag = true;
				}
			}			

			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return flag;
	}

	public College getCollege(){
		return college;
	}

	public void setCollegeBranchId(Integer collegeBranchId){
		this.collegeBranchId = collegeBranchId;
	}

	public Integer getCollegeBranchId(){
		return collegeBranchId;
	}

}