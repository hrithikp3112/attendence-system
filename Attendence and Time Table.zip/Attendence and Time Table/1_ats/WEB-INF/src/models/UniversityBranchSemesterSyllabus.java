package models;

public class UniversityBranchSemesterSyllabus{
	private Integer universityBranchSemesterSyllabusId;
	private UniversityBranchSemester universityBranchSemester;
	private Subject subject;

//##################################################################
	public void setUniversityBranchSemesterSyllabusId(Integer universityBranchSemesterSyllabusId){
		this.universityBranchSemesterSyllabusId = universityBranchSemesterSyllabusId;
	}

	public Integer getUniversityBranchSemesterSyllabusId(){
		return universityBranchSemesterSyllabusId;
	}

//##################################################################
	public void setUniversityBranchSemester(UniversityBranchSemester universityBranchSemester){
		this.universityBranchSemester = universityBranchSemester;
	}
	public UniversityBranchSemester getUniversityBranchSemester(){
		return universityBranchSemester;
	}

//##################################################################
	public void setSubject(Subject subject){
		this.subject = subject;
	}

	public Subject getSubject(){
		return subject;
	}
}