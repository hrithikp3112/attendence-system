package models;
import java.sql.Timestamp;


public class Attendance{
	private Integer attendanceId;
	private Student student;
	private CollegeSchedule collegeSchedule;
	private Timestamp date;
	private boolean status;

//##################################################################
	public void setAttendanceId(Integer attendanceId){
		this.attendanceId = attendanceId;
	}

	public Integer getAttendanceId(){
		return attendanceId;
	}

//##################################################################
	public void setStudent(Student student){
		this.student = student;
	}

	public Student getStudent(){
		return student;
	}

//##################################################################
	public void setCollegeSchedule(CollegeSchedule collegeSchedule){
		this.collegeSchedule = collegeSchedule;
	}

	public CollegeSchedule getCollegeSchedule(){
		return collegeSchedule;
	}

//##################################################################
	public void setDate(Timestamp date){
		this.date = date;
	}

	public Timestamp getDate(){
		return date;
	}

//##################################################################
	public void setStatus(boolean status){
		this.status = status;
	}

	public boolean getStatus(){
		return status;
	}

//##################################################################

}