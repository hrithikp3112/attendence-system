package models;

import java.sql.*;
import java.util.*;

public class Batch{
	private Integer batchId;
	private Integer startYear;
	private Integer endYear;
	
	public Batch(){
	
	}

	public Batch(Integer batchId){
		this.batchId = batchId;
	}

	public Batch(Integer batchId,Integer startYear,Integer endYear){
		this.batchId = batchId;
		this.startYear = startYear;
		this.endYear = endYear;
	}

	public static ArrayList<Batch> collectCollegeBatches(Integer collegeId){
		ArrayList<Batch> batches = new ArrayList<Batch>();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String query = "select cb.batch_id,start_year,end_year from college_batches as cb inner join batches as b where college_id=? and cb.batch_id=b.batch_id";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1,collegeId);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				batches.add(new Batch(rs.getInt(1),rs.getInt(2),rs.getInt(3)));
			}			

			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return batches;
	}


	public static ArrayList<Batch> collectAllBatches(){
		ArrayList<Batch> batches = new ArrayList<Batch>();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String query = "select * from batches";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				batches.add(new Batch(rs.getInt(1),rs.getInt(2),rs.getInt(3)));
			}			

			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return batches;
	}
//##################################################################
	public void setBatchId(Integer batchId){
		this.batchId = batchId;
	}

	public Integer getBatchId(){
		return batchId;
	}

//##################################################################
	public void setStartYear(Integer startYear){
		this.startYear = startYear;
	}

	public Integer getStartYear(){
		return startYear;
	}

//##################################################################
	public void setEndYear(Integer endYear){
		this.endYear = endYear;
	}

	public Integer getEndYear(){
		return endYear;
	}

}