package models;

import java.sql.*;

public class CollegeBatchBranch{
	private Integer collegeBatchBranchId;
	private CollegeBatch collegeBatch;
	private Branch branch;
	
	
	public static boolean saveCollegeBatchBranches(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "insert ignore into college_batch_branches (college_batch_id,branch_id) ";
			String q2 = "(select cbt.college_batch_id,cbr.branch_id from college_batches as cbt ";
			String q3 = "cross join college_branches as cbr where cbt.college_batch_id=college_batch_id)";
			PreparedStatement ps = con.prepareStatement(q1+q2+q3);
			
			if(ps.executeUpdate()!=0){
				flag = true;
			}			

			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return flag;
	}

//################################################################################
	public void setCollegeBatchBranchId(Integer collegeBatchBranchId){
		this.collegeBatchBranchId = collegeBatchBranchId;
	}

	public Integer getCollegeBatchBranchId(){
		return collegeBatchBranchId;
	}

//################################################################################
	public void setCollegeBatch(CollegeBatch collegeBatch){
		this.collegeBatch = collegeBatch;
	}
	public CollegeBatch getCollegeBatch(){
		return collegeBatch;
	}

//################################################################################
	public void setBranch(Branch branch){
		this.branch = branch;
	}

	public Branch getBranch(){
		return branch;
	}
}