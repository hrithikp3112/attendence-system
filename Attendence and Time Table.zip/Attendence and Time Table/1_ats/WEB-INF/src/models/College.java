package models;

import java.sql.*;
import java.util.*;

public class College{
	//### Properties #############################
	private Integer collegeId;
	private String collegeName;
	private String activationCode;
	private Status status;
	private City city;
	private String pincode;
	private String address;
	private String email;
	private String password;
	private String details;
	private String principalsName;
	private String contact;
	private University university;
	private String registrationCode;
	private java.sql.Date foundationDate;

	//### Constructors #############################
	public College(String email,String password){
		this.email = email;
		this.password = password;
	}

	public College(){
	
	}



	//### Other - Methods ######################################
	public boolean loginCollege(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select college_id,college_name,c.city_id,city_name,";
			String q2 = "st.state_id,state_name,pincode,address,details,";
			String q3 = "principals_name,contact,u.university_id,university,";
			String q4 = "registration_code,foundation_date,s.status_id,status ";
			String q5 = "from colleges as cl inner join cities as c ";
			String q6 = "inner join states as st inner join universities as u ";
			String q7 = "inner join statuz as s where cl.city_id=c.city_id and ";
			String q8 = "c.state_id=st.state_id and cl.university_id=u.university_id ";
			String q9 = "and cl.status_id=s.status_id and email=? and password=?";

			PreparedStatement ps = con.prepareStatement(q1+q2+q3+q4+q5+q6+q7+q8+q9);
			ps.setString(1,email);
			ps.setString(2,password);

			ResultSet rs = ps.executeQuery();

			if(rs.next()){
				collegeId = rs.getInt(1);
				collegeName = rs.getString(2);				
				city = new City(rs.getInt(3),rs.getString(4),new State(rs.getInt(5),rs.getString(6)));
				pincode = rs.getString(7);
				address = rs.getString(8);
				details = rs.getString(9);
				principalsName = rs.getString(10);
				contact = rs.getString(11);
				university = new University(rs.getInt(12),rs.getString(13));
				registrationCode = rs.getString(14);
				foundationDate = rs.getDate(15);
				status = new Status(rs.getInt(16),rs.getString(17));

				flag = true;
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}	

		return flag;
	}

	public void registerCollege(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "insert into colleges (college_name,city_id,";
			String q2 = "activation_code,pincode,address,email,password,";
			String q3 = "details,principals_name,contact,university_id,";
			String q4 = "registration_code,foundation_date) value ";
			String q5 = "(?,?,?,?,?,?,?,?,?,?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(q1+q2+q3+q4+q5);
			
			ps.setString(1,collegeName);
			ps.setInt(2,city.getCityId());
			ps.setString(3,(int)Math.floor(new Random().nextDouble()*1000000)+"_"+new java.util.Date().getTime());
			ps.setString(4,pincode);
			ps.setString(5,address);
			ps.setString(6,email);
			ps.setString(7,password);
			ps.setString(8,details);
			ps.setString(9,principalsName);
			ps.setString(10,contact);
			ps.setInt(11,university.getUniversityId());
			ps.setString(12,registrationCode);
			ps.setDate(13,foundationDate);

			ps.executeUpdate();

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}



	//### Getter-Setters ##############################
//#######################################################
	public void setCollegeId(Integer collegeId){
		this.collegeId = collegeId;
	}

	public Integer getCollegeId(){
		return collegeId;
	}

//#######################################################
	public void setCollegeName(String collegeName){
		this.collegeName = collegeName;
	}

	public String getCollegeName(){
		return collegeName;
	}

//#######################################################
	public void setActivationCode(String activationCode){
		this.activationCode = activationCode;
	}

	public String getActivationCode(){
		return activationCode;
	}

//#######################################################	
	public void setStatus(Status status){
		this.status = status;
	}

	public Status getStatus(){
		return status;
	}

//#######################################################
	public void setCity(City city){
		this.city = city;
	}

	public City getCity(){
		return city;
	}

//#######################################################
	public void setPincode(String pincode){
		this.pincode = pincode;
	}

	public String getPincode(){
		return pincode;
	}

//#######################################################
	public void setAddress(String address){
		this.address = address;
	}

	public String getAddress(){
		return address;
	}

//#######################################################
	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

//#######################################################
	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return password;
	}

//#######################################################
	public void setDetails(String details){
		this.details = details;
	}

	public String getDetails(){
		return details;
	}

//#######################################################
	public void setPrincipalsName(String principalsName){
		this.principalsName = principalsName;
	}

	public String getPrincipalsName(){
		return principalsName;
	}

//#######################################################
	public void setContact(String contact){
		this.contact = contact;
	}

	public String getContact(){
		return contact;
	}

//#######################################################
	public void setUniversity(University university){
		this.university = university;
	}

	public University getUniversity(){
		return university;
	}

//#######################################################
	public void setRegistrationCode(String registrationCode){
		this.registrationCode = registrationCode;
	}

	public String getRegistrationCode(){
		return registrationCode;
	}

//#######################################################
	public void setFoundationDate(java.sql.Date foundationDate){
		this.foundationDate = foundationDate;
	}

	public java.sql.Date getFoundationDate(){
		return foundationDate;
	}
}