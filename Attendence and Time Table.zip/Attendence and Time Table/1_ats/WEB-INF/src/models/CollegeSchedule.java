package models;

public class CollegeSchedule{
	private Integer collegeScheduleId;
	private CollegeBatchBranchSemester collegeBatchBranchSemester;
	private CollegeTimeSlot collegeTimeSlot;
	private Faculty faculty;
	private UniversityBranchSemesterSyllabus universityBranchSemesterSyllabus;

//######################################################################
	public void setCollegeScheduleId(Integer collegeScheduleId){
		this.collegeScheduleId = collegeScheduleId;
	}

	public Integer getCollegeScheduleId(){
		return collegeScheduleId;
	}

//######################################################################
	public void setCollegeBatchBranchSemester(CollegeBatchBranchSemester collegeBatchBranchSemester){
		this.collegeBatchBranchSemester = collegeBatchBranchSemester;
	}
	public CollegeBatchBranchSemester getCollegeBatchBranchSemester(){
		return collegeBatchBranchSemester;
	}

//######################################################################
	public void setCollegeTimeSlot(CollegeTimeSlot collegeTimeSlot){
		this.collegeTimeSlot = collegeTimeSlot;
	}

	public CollegeTimeSlot getCollegeTimeSlot(){
		return collegeTimeSlot;
	}

//######################################################################
	public void setFaculty(Faculty faculty){
		this.faculty = faculty;
	}

	public Faculty getFaculty(){
		return faculty;
	}

//######################################################################
	public void setUniversityBranchSemesterSyllabus(UniversityBranchSemesterSyllabus universityBranchSemesterSyllabus){
		this.universityBranchSemesterSyllabus = universityBranchSemesterSyllabus;
	}

	public UniversityBranchSemesterSyllabus getUniversityBranchSemesterSyllabus(){
		return universityBranchSemesterSyllabus;
	}
}