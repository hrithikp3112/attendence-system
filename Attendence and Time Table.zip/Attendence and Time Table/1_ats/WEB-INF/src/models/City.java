package models;

import java.util.ArrayList;
import java.sql.*;

public class City{
	private Integer cityId;
	private String cityName;
	private State state;

	public City(){
	
	}

	public City(Integer cityId){
		this.cityId = cityId;
	}

	public City(Integer cityId,String cityName,State state){
		this.cityId = cityId;
		this.cityName = cityName;
		this.state = state;
	}

	//##################################################################

	public static ArrayList<City> collectCities(){
		ArrayList<City> cities = new ArrayList<City>();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select city_id,city_name,c.state_id,state_name "; 
			String q2 = "from cities as c inner join states as s where ";
			String q3 = "c.state_id=s.state_id";
			PreparedStatement ps = con.prepareStatement(q1+q2+q3);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				cities.add(new City(rs.getInt(1),rs.getString(2),new State(rs.getInt(3),rs.getString(4))));
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	
		return cities;
	}


//##################################################################
	public void setCityId(Integer cityId){
		this.cityId = cityId;
	}

	public Integer getCityId(){
		return cityId;
	}

//##################################################################
	public void setCityName(String cityName){
		this.cityName = cityName;
	}
	public String getCityName(){
		return cityName;
	}

//##################################################################
	public void setState(State state){
		this.state = state;
	}

	public State getState(){
		return state;
	}
}