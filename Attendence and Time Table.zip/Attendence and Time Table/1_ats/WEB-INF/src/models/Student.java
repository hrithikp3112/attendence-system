package models;
import java.sql.*;

public class Student{
	private Integer studentId;
	private String studentName;
	private String picPath;
	private String fathersName;
	private String mothersName;
	private Date dob;
	private String address;
	private City city;
	private String contact;
	private String email;
	private String password;
	private String parentsContact;
	private CollegeBatchBranchSemester collegeBatchBranchSemester;

//#######################################################
	public void setStudentId(Integer studentId){
		this.studentId = studentId;
	}

	public Integer getStudentId(){
		return studentId;
	}

//#######################################################
	public void setStudentName(String studentName){
		this.studentName = studentName;
	}

	public String getStudentName(){
		return studentName;
	}

//#######################################################
	public void setPicPath(String picPath){
		this.picPath = picPath;
	}

	public String getPicPath(){
		return picPath;
	}

//#######################################################
	public void setFathersName(String fathersName){
		this.fathersName = fathersName;
	}

	public String getFathersName(){
		return fathersName;
	}

//#######################################################
	public void setMothersName(String mothersName){
		this.mothersName = mothersName;
	}

	public String getMothersName(){
		return mothersName;
	}

//#######################################################
	public void setDob(Date dob){
		this.dob = dob;
	}

	public Date getDob(){
		return dob;
	}

//#######################################################

	public void setAddress(String address){
		this.address = address;
	}

	public String getAddress(){
		return address;
	}

//#######################################################
	public void setCity(City city){
		this.city = city;
	}

	public City getCity(){
		return city;
	}

//#######################################################
	public void setContact(String contact){
		this.contact = contact;
	}

	public String getContact(){
		return contact;
	}

//#######################################################
	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}

//#######################################################
	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return password;
	}

//#######################################################
	public void setParentsContact(String parentsContact){
		this.parentsContact = parentsContact;
	}

	public String getParentsContact(){
		return parentsContact;
	}

//#######################################################
	public void setCollegeBatchBranchSemester(CollegeBatchBranchSemester CollegeBatchBranchSemester){
		this.collegeBatchBranchSemester = collegeBatchBranchSemester;
	}

	public CollegeBatchBranchSemester getCollegeBatchBranchSemester(){
		return collegeBatchBranchSemester;
	}

}
	