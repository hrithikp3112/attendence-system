package models;

import java.sql.*;
import java.util.*;

public class Branch{
	private Integer branchId;
	private String branch;

	public Branch(){
	
	}

	public Branch(Integer branchId){
		this.branchId = branchId;
	}

	public Branch(Integer branchId,String branch){
		this.branchId = branchId;
		this.branch = branch;
	}

	public static ArrayList<Branch> collectCollegeBranches(Integer collegeId){
		ArrayList<Branch> branches = new ArrayList<Branch>();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String query = "select cb.branch_id,branch from college_branches as cb inner join branches as b where cb.branch_id=b.branch_id and college_id=?";
			
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1,collegeId);

			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				branches.add(new Branch(rs.getInt(1),rs.getString(2)));
			}
			
			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return branches;
	}

	public static ArrayList<Branch> collectUnivBranches(Integer univId){
		ArrayList<Branch> branches = new ArrayList<Branch>();

		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select b.branch_id,branch from university_branches ";
			String q2 = " as ub inner join branches as b ";
			String q3 = "where ub.branch_id=b.branch_id and university_id=?";

			PreparedStatement ps = con.prepareStatement(q1+q2+q3);
			ps.setInt(1,univId);

			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				branches.add(new Branch(rs.getInt(1),rs.getString(2)));
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}

		return branches;
	}

//##################################################################
	public void setBranchId(Integer branchId){
		this.branchId = branchId;
	}

	public Integer getBranchId(){
		return branchId;
	}

//##################################################################
	public void setBranch(String branch){
		this.branch = branch;
	}

	public String getBranch(){
		return branch;
	}

}