package models;

import java.sql.*;

public class CollegeBatchBranchSemester{
	private Integer collegeBatchBranchSemesterId;
	private CollegeBatchBranch collegeBatchBranch;
	private Semester semester;

	public static boolean saveCollegeBatchBranchSemesters(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "insert ignore into college_batch_branch_semesters ";
			String q2 = "(college_batch_branch_id,semester_id) ";
			String q3 = "(select cbb.college_batch_branch_id,s.semester_id  ";
			String q4 = "from college_batch_branches as cbb cross join semesters as s ";
			String q5 = "where cbb.college_batch_branch_id=college_batch_branch_id)";
			PreparedStatement ps = con.prepareStatement(q1+q2+q3+q4+q5);
			
			if(ps.executeUpdate()!=0){
				flag = true;
			}			

			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return flag;
	}

//################################################################################
	public void setCollegeBatchBranchSemesterId(Integer collegeBatchBranchSemesterId){
		this.collegeBatchBranchSemesterId = collegeBatchBranchSemesterId;
	}

	public Integer getCollegeBatchBranchSemesterId(){
		return collegeBatchBranchSemesterId;
	}

//################################################################################
	public void setCollegeBatchBranch(CollegeBatchBranch collegeBatchBranch){
		this.collegeBatchBranch = collegeBatchBranch;
	}
	public CollegeBatchBranch getCollegeBatchBranch(){
		return collegeBatchBranch;
	}

//################################################################################
	public void setSemester(Semester semester){
		this.semester = semester;
	}

	public Semester getSemester(){
		return semester;
	}
}