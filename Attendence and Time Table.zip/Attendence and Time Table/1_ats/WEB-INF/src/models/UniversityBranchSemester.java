package models;

public class UniversityBranchSemester{
	private Integer universityBranchSemesterId;
	private UniversityBranch universityBranch;
	private Semester semester;

//##################################################################
	public void setUniversityBranchSemesterId(Integer universityBranchSemesterId){
		this.universityBranchSemesterId = universityBranchSemesterId;
	}

	public Integer getUniversityBranchSemesterId(){
		return universityBranchSemesterId;
	}

//##################################################################
	public void setUniversitySemester(UniversityBranch universityBranch){
		this.universityBranch = universityBranch;
	}
	public UniversityBranch getUniversityBranch(){
		return universityBranch;
	}

//##################################################################
	public void setSemester(Semester semester){
		this.semester = semester;
	}

	public Semester getSemester(){
		return semester;
	}
}