package models;

public class UniversityBranch{
	private Integer universityBranchId;
	private University university;
	private Branch branch;

	public UniversityBranch(){
	
	}	

	//other methods ####################

	


//##################################################################
	public void setUniversityBranchId(Integer universityBranchId){
		this.universityBranchId = universityBranchId;
	}

	public Integer getUniversityBranchId(){
		return universityBranchId;
	}

//##################################################################
	public void setUniversity(University university){
		this.university = university;
	}
	public University getUniversity(){
		return university;
	}

//##################################################################
	public void setBranch(Branch branch){
		this.branch = branch;
	}

	public Branch getBranch(){
		return branch;
	}
}