package models;

import java.util.ArrayList;
import java.sql.*;

public class University{
	private Integer universityId;
	private String universityName;
	private City city;

	public University(){
	
	}

	public University(Integer universityId){
		this.universityId = universityId;
	}

	public University(Integer universityId,String universityName){
		this.universityId = universityId;
		this.universityName = universityName;
	}

	public University(Integer universityId,String universityName,City city){
		this.universityId = universityId;
		this.universityName = universityName;
		this.city = city;
	}

	public static ArrayList<University> collectUniversities(){
		ArrayList<University> universities = new ArrayList<University>();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select university_id,university,u.city_id,";
			String q2 = "city_name,c.state_id,state_name from ";
			String q3 = "universities as u inner join cities as c ";
			String q4 = "inner join states as s where u.city_id=c.city_id ";
			String q5 = "and c.state_id=s.state_id";

			PreparedStatement ps = con.prepareStatement(q1+q2+q3+q4+q5);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				universities.add(new University(
												rs.getInt(1),
												rs.getString(2),
												new City(
														rs.getInt(3),
														rs.getString(4),
														new State(
																rs.getInt(5),
																rs.getString(6)))));
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	
		return universities;
	}

 //##################################################################
	public void setUniversityId(Integer universityId){
		this.universityId = universityId;
	}

	public Integer getUniversityId(){
		return universityId;
	}

//##################################################################
	public void setUniversityName(String universityName){
		this.universityName = universityName;
	}
	public String getUniversityName(){
		return universityName;
	}

//##################################################################
	public void setCity(City city){
		this.city = city;
	}

	public City getCity(){
		return city;
	}
}