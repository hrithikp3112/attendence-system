package models;

import java.util.*;
import java.sql.*;

public class Designation{
	private Integer designationId;
	private String designation;
		
	public Designation(){
	
	}

	public Designation(Integer designationId,String designation){
		this.designationId = designationId;
		this.designation = designation;
	}

	public static ArrayList<Designation> collectDesignations(){
		ArrayList<Designation> designations = new ArrayList<Designation>();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select * from designations";
			PreparedStatement ps = con.prepareStatement(q1);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				designations.add(new Designation(rs.getInt(1),rs.getString(2)));
			}

			con.close();
		}catch(SQLException e){
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	
		return designations;
	}

//##################################################################
	public void setDesignationId(Integer designationId){
		this.designationId = designationId;
	}

	public Integer getDesignationId(){
		return designationId;
	}

//##################################################################
	public void setDesignation(String designation){
		this.designation = designation;
	}

	public String getDesignation(){
		return designation;
	}

}