package models;

import java.sql.*;

public class CollegeBatch{
	private Integer collegeBatchId;
	private College college;
	private Batch batch;

	public CollegeBatch(){
	
	}

	public CollegeBatch(College college,Batch batch){
		this.college = college;
		this.batch = batch;
	}

	public boolean saveCollegeBatch(){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ats?user=root&password=1234");
			
			String q1 = "select college_batch_id from college_batches where college_id=? and batch_id=?";
			PreparedStatement p1 = con.prepareStatement(q1);
			p1.setInt(1,college.getCollegeId());
			p1.setInt(2,batch.getBatchId());
			ResultSet r1 = p1.executeQuery();
			
			if(!r1.next()){
				String query = "insert ignore into college_batches (college_id,batch_id) value (?,?)";
				PreparedStatement ps = con.prepareStatement(query);
				ps.setInt(1,college.getCollegeId());
				ps.setInt(2,batch.getBatchId());

				if(ps.executeUpdate()!=0){
					if(CollegeBatchBranch.saveCollegeBatchBranches()){
						if(CollegeBatchBranchSemester.saveCollegeBatchBranchSemesters()){
							flag = true;	
						}
					}
				}				
			}

			con.close();
		}catch(SQLException|ClassNotFoundException e){
			e.printStackTrace();
		}

		return flag;
	}
//##################################################################
	public void setCollegeBatchId(Integer collegeBatchId){
		this.collegeBatchId = collegeBatchId;
	}

	public Integer getCollegeBatchId(){
		return collegeBatchId;
	}

//##################################################################
	public void setCollege(College college){
		this.college = college;
	}
	public College getCollege(){
		return college;
	}

//##################################################################
	public void setBatch(Batch batch){
		this.batch = batch;
	}

	public Batch getBatch(){
		return batch;
	}
}