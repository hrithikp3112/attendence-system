package listeners;

import javax.servlet.ServletContextListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContext;

import models.*;

import java.util.ArrayList;


public class AppListener implements ServletContextListener{
	public void contextInitialized(ServletContextEvent ev){
		ServletContext context = ev.getServletContext();
		
		ArrayList<State> states = State.collectStates();
		ArrayList<City> cities = City.collectCities();
		ArrayList<University> universities = University.collectUniversities();
		ArrayList<Batch> batches = Batch.collectAllBatches();
		ArrayList<Designation> designations = Designation.collectDesignations();
		/*
		ArrayList<Subject> subjects = Subject.collectSubjects();
		ArrayList<Branch> branches = Branch.collectBranches();
		ArrayList<Semester> semesters = Semester.collectSemesters();
		
		
		*/

		context.setAttribute("states",states);
		context.setAttribute("cities",cities);
		context.setAttribute("universities",universities);
		context.setAttribute("batches",batches);
		context.setAttribute("designations",designations);
		/*
		context.setAttribute("subjects",subjects);
		context.setAttribute("branches",branches);
		context.setAttribute("semesters",semesters);
		
				*/

	}

	public void contextDestroyed(ServletContextEvent ev){
		
	}
}