package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import models.*;

public class SaveBranchServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();

		String result = "timeout";
		
		College college = (College)session.getAttribute("college");

		if(college!=null){
			int branchId = Integer.parseInt(request.getParameter("branch_id"));
		
			CollegeBranch collegeBranch = new CollegeBranch(college,new Branch(branchId));
			if(collegeBranch.saveCollegeBranch()){
				result = "success";	
			}else{
				result = "fail";
			}
		}
		
		response.getWriter().write(result);
	}
}