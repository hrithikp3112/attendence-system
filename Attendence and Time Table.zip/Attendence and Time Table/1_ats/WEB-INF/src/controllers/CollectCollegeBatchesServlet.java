package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import java.util.*;
import models.*;

import com.google.gson.Gson;

public class CollectCollegeBatchesServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();

		College college = (College)session.getAttribute("college");
		
		String resp = "fail";
		
		if(college!=null){
			ArrayList<Batch> batches = Batch.collectCollegeBatches(college.getCollegeId());
			
			resp = new Gson().toJson(batches);
		}
		
		response.getWriter().write(resp);		
	}
}