package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import models.*;
import java.util.*;

import com.google.gson.Gson;

public class CollectUnivBranchesServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();

		College college = (College)session.getAttribute("college");

		if(college!=null){
			ArrayList<Branch> branches = Branch.collectUnivBranches(college.getUniversity().getUniversityId());
			response.getWriter().write(new Gson().toJson(branches));
		}		
	}
}