package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import models.*;
import java.util.ArrayList;
import com.google.gson.Gson;

public class CollectBatchesServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();

		College college = (College)session.getAttribute("college");
		
		String resp = "fail";

		if(college!=null){
			ArrayList<Batch> batches = Batch.collectAllBatches();
			resp = new Gson().toJson(batches);
		}

		response.getWriter().write(resp);
	}
}