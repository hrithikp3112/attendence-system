package controllers;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

import models.*;

public class RegisterCollegeServlet extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();
		
		String collegeName = request.getParameter("clg_nm");
		String principalName = request.getParameter("prn_nm");
		String address = request.getParameter("adr");
		Integer cityId = Integer.parseInt(request.getParameter("city_id"));
		String pin = request.getParameter("pin");
		String contact = request.getParameter("contact");
		String email = request.getParameter("email");
		String password = request.getParameter("pwd");
		String details = request.getParameter("details");
		String foundedOn = request.getParameter("foundedon");
		Integer universityId = Integer.parseInt(request.getParameter("univ_id"));
		String registrationCode = request.getParameter("reg_code");

		//Form Validation ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		College college = new College();
		college.setCollegeName(collegeName);
		college.setPrincipalsName(principalName);
		college.setAddress(address);
		college.setCity(new City(cityId));
		college.setPincode(pin);
		college.setContact(contact);
		college.setEmail(email);
		college.setPassword(password);
		college.setDetails(details);
		college.setFoundationDate(java.sql.Date.valueOf(foundedOn));
		college.setUniversity(new University(universityId));
		college.setRegistrationCode(registrationCode);
		
		college.registerCollege();
		
		request.getRequestDispatcher("college.jsp").forward(request,response);
	}
}