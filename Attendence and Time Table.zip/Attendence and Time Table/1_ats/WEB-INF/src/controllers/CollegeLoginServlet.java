package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import models.College;

public class CollegeLoginServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();
		
		String nextPage = "college.jsp";

		String email = request.getParameter("email");
		String password = request.getParameter("pwd");

		//validation

		College college = new College(email,password);
		//college.setEmail(email);
		//college.setPassword(password);

		if(college.loginCollege()){
			nextPage = "college_dashboard.jsp";
			session.setAttribute("college",college);
		}else{
			
		}

		request.getRequestDispatcher(nextPage).forward(request,response);
	}
}