package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import models.*;

public class SaveCollegeBatchServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();
		
		College college = (College)session.getAttribute("college");
		String resp = "timeout";

		if(college!=null){

			int batchId = Integer.parseInt(request.getParameter("batch_id")); 
			
			CollegeBatch collegeBatch = new CollegeBatch(college,new Batch(batchId));
			
			if(collegeBatch.saveCollegeBatch()){
				resp = "success";
			}else{
				resp = "fail";
			}
		}	

		response.getWriter().write(resp);
	}
}