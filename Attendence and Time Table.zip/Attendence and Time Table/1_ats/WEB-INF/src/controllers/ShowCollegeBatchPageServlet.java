package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import models.College;

public class ShowCollegeBatchPageServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();
		
		String nextPage = "college.jsp";

		College college = (College)session.getAttribute("college");

		if(college!=null){
			nextPage = "college_batches.jsp";
		}else{
			//message ################
		}



		

		request.getRequestDispatcher(nextPage).forward(request,response);
	}
}