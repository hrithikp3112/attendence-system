package controllers;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import java.util.*;
import models.*;

public class TServlet extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
		HttpSession session = request.getSession();
		String nextPage = "";

		String tmp = request.getParameter("");

		request.getRequestDispatcher(nextPage).forward(request,response);
	}
}