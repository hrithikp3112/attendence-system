import java.util.ArrayList;
import java.sql.*;

class B{

	public static Connection con=null;
	static ArrayList<UniversityBranch> uniBranch=new ArrayList();
	static ArrayList<String> semester= new ArrayList();
	

	static{
		try{
				Class.forName("com.mysql.jdbc.Driver");
				con= DriverManager.getConnection("jdbc:mysql://localhost:3306/ats","root","1234");
		
		}catch(ClassNotFoundException|SQLException e){
			e.printStackTrace();
			
		}
	}

	public static void addUniBranch(){
		uniBranch.add(new UniversityBranch(1,1));
		uniBranch.add(new UniversityBranch(1,2));
		uniBranch.add(new UniversityBranch(1,4));
		uniBranch.add(new UniversityBranch(2,1));
		uniBranch.add(new UniversityBranch(2,2));
		uniBranch.add(new UniversityBranch(2,4));	
		uniBranch.add(new UniversityBranch(7,1));
		uniBranch.add(new UniversityBranch(7,2));
		uniBranch.add(new UniversityBranch(7,4));
		System.out.println(uniBranch);

		saveUniBranch(uniBranch);
	}
	public static void addSemester(){
		semester.add("First");
		semester.add("Second");
		semester.add("Third");
		semester.add("Fourth");
		semester.add("Fifth");
		semester.add("Sixth");
		semester.add("Seventh");
		semester.add("Eighth");
		
		System.out.println(semester);
		saveSemester(semester);
	}


		public static void saveSubject(ArrayList<String> subject){
		try{
			String query="insert into subjects(subject) value(?)";
			PreparedStatement ps= con.prepareStatement(query);

			for(String s:subject){
			ps.setString(1,s);
			System.out.println("save~~"+s);
			ps.executeUpdate();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}	

	public static void saveSemester(ArrayList<String> semester){
		try{
			String query="insert into semesters(semester) value(?)";
			PreparedStatement ps= con.prepareStatement(query);

			for(String s:semester){
			ps.setString(1,s);
			System.out.println("save"+s);
			ps.executeUpdate();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}	




	public static void saveUniBranch(ArrayList<UniversityBranch> uniBranch){
		try{
			
			String query="insert into university_branches (university_id,branch_id) values (?,?)";
			PreparedStatement ps= con.prepareStatement(query);

			for(UniversityBranch ub: uniBranch){
				ps=con.prepareStatement(query);
			
				ps.setInt(1,ub.getUniversityId());
				ps.setInt(2,ub.getBranchId());
				System.out.println(ub.getUniversityId());
				System.out.println(ub.getBranchId());
				ps.executeUpdate();
			

			}
			
		
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	}

		public static void saveUniBranchSem(ArrayList<UniversityBranchSemester> uniBranchSem){
		try{
			
			String query="insert into university_branch_semesters (university_branch_id,semester_id) values (?,?)";
			PreparedStatement ps= con.prepareStatement(query);

			for(UniversityBranchSemester ubs:uniBranchSem ){
				ps=con.prepareStatement(query);
			
				ps.setInt(1,ubs.getUniversityBranchId());
				ps.setInt(2,ubs.getSemesterId());
				System.out.println(ubs.getUniversityBranchId());
				System.out.println(ubs.getSemesterId());
				ps.executeUpdate();
			

			}
			
		
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	}

	public static void saveUniBranchSemSyllabus(ArrayList<UniversityBranchSemesterSyllabus> uniBranchSemSyllabus){
		try{
			
			String query="insert into university_branch_semester_syllabuses (university_branch_semester_id,subject_id) values (?,?)";
			PreparedStatement ps= con.prepareStatement(query);

			for(UniversityBranchSemesterSyllabus ubss:uniBranchSemSyllabus ){
				ps=con.prepareStatement(query);
			
				ps.setInt(1,ubss.getUniversityBranchSemesterId());
				ps.setInt(2,ubss.getSubjectId());
				System.out.println(ubss.getUniversityBranchSemesterId());
				System.out.println(ubss.getSubjectId());
				ps.executeUpdate();
			

			}
			
		
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args){
		//addUniBranch();
		//addSemester();
		//new Subject().addSubjects();
		//new UniversityBranchSemester().addUniBranchSem();
		new UniversityBranchSemesterSyllabus().addUniBranchSemSyllabus();
		
	}
	
}