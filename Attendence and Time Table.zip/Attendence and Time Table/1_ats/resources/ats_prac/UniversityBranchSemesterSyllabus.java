import java.util.ArrayList;

public class UniversityBranchSemesterSyllabus {
	int universityBranchSemesterId;
	int subjectId;
	
	public int getUniversityBranchSemesterId() {
		return universityBranchSemesterId;
	}
	public void setUniversityBranchSemesterId(int universityBranchSemesterId) {
		this.universityBranchSemesterId = universityBranchSemesterId;
	}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	
	public UniversityBranchSemesterSyllabus(int universityBranchSemesterId, int subjectId) {
		
		this.universityBranchSemesterId = universityBranchSemesterId;
		this.subjectId = subjectId;
	}
	public UniversityBranchSemesterSyllabus() {
		
	}
	static ArrayList<UniversityBranchSemesterSyllabus> ubss= new ArrayList();

	public static void addUniBranchSemSyllabus(){
		
		for(int i=0;i<=64;i+=8){
		ubss.add(new UniversityBranchSemesterSyllabus(i+1,1));
		ubss.add(new UniversityBranchSemesterSyllabus(i+1,2));
		ubss.add(new UniversityBranchSemesterSyllabus(i+1,3));
		ubss.add(new UniversityBranchSemesterSyllabus(i+1,4));
		ubss.add(new UniversityBranchSemesterSyllabus(i+1,5));
		ubss.add(new UniversityBranchSemesterSyllabus(i+2,6));
		ubss.add(new UniversityBranchSemesterSyllabus(i+2,7));
		ubss.add(new UniversityBranchSemesterSyllabus(i+2,8));
		ubss.add(new UniversityBranchSemesterSyllabus(i+2,9));
		ubss.add(new UniversityBranchSemesterSyllabus(i+2,10));
		for(int j=3;j<=8;j++){
			int k=0;
		ubss.add(new UniversityBranchSemesterSyllabus(j,j+8+k));
		ubss.add(new UniversityBranchSemesterSyllabus(j,j+9+k));
		ubss.add(new UniversityBranchSemesterSyllabus(j,j+10+k));
		ubss.add(new UniversityBranchSemesterSyllabus(j,j+11+k));
		ubss.add(new UniversityBranchSemesterSyllabus(j,j+12+k));
			k=k+4;
		}
	}
		new B().saveUniBranchSemSyllabus(ubss);
		}

		

}
