import java.util.ArrayList;

public class Subject{
	static ArrayList<String> subject= new ArrayList();
		public static void addSubjects(){
			//sem 1 common for all
			subject.add("Engg. Mathematics-I ");
			subject.add("Electronics Engg ");
			subject.add("Engg. Chemistry ");
			subject.add("Computer System andProgramming in C  ");
			subject.add("Engg. Physics-I ");
			subject.add("Environment & Ecology ");
			subject.add(" Computer Aided Engg. Graphics ");
			//sem 2 common for all
			subject.add("Engg. Mathematics-II  ");
			subject.add("Professional Communication   ");
			subject.add("Professional Communication   ");
			subject.add("Engg. Mechanics ");
			subject.add("Basic Electrical Engg. ");
			subject.add("Engg. Physics-II . ");
			subject.add("Basic Manufacturing Processes ");
			subject.add("Workshop Practice  ");
			//cse sem 3
			subject.add("Programming using C++ ");
			subject.add("Principles of Computer Engineering ");
			subject.add("Algebra and Number Theory");
			subject.add("Computer Architecture");
			subject.add("Data Structures");
			subject.add("Database Management Systems");
			subject.add("Electronic Devices and Circuits For Computer Engineers");
			//cse sem 4
			subject.add("Probability and Queueing Theory");
			subject.add("Design and Analysis of Algorithms ");
			subject.add("Java and Internet Programming");
			subject.add("Operating Systems");
			subject.add("Software Engineering");
			subject.add("Electrical Engineering and Control Systems");
			//cse sem 5
			subject.add("Data Communication and Computer Networks");
			subject.add("Microprocessors and Micro Controllers");
			subject.add("System Software Internals");
			subject.add("Theory of Computation");
			subject.add("Object Oriented Analysis and Design ");
			subject.add("Employability Skills");
			//cse sem 6
			subject.add("Artificial Intelligence");
			subject.add("Compiler Design");
			subject.add("Computer Graphics and Multimedia");
			subject.add("Programming Paradigms");
			subject.add("Digital Signal Processing � Algorithms and Applications ");
			subject.add("Creative and Innovative Project ");
			//cse sem 7
			subject.add("Principles of Management");
			subject.add("Mobile and Pervasive Computing");
			subject.add("Parallel Programming ");
			subject.add("Security in Computing");
			//cse sem 8
			subject.add("Mobile Application Development ");
			subject.add("Compiler design");
			subject.add("Web Engg");
			subject.add("Big Data");
			//Elective
			subject.add("Net & C# Programming");
			subject.add("Adhoc & Sensor Networks");
			subject.add("Advanced Topics on Databases");
			subject.add("Bio Informatics Technologies");
			subject.add("Cloud Computing and Services ");
			subject.add("Computational Intelligence");
			subject.add("Data Warehousing & Data Mining");
			subject.add("Database Tuning");
			subject.add("E-Learning Techniques");
			subject.add("Information Retrieval & Management");
			subject.add("Human Computer Interaction");
			subject.add("Nano Computing");
			subject.add("Natural Language Processing");
			subject.add("Network Analysis & Management");
			subject.add("Principles of Cryptography & Network Security");
			subject.add("Software Quality & Testing");

			//ec sem 3
			subject.add("Transforms and Partial Differential Equations");
			subject.add("Electrical Engineering and Instrumentation ");
			subject.add("Object Oriented Programming and Data Structures");
			subject.add("Digital Electronics");
			subject.add("Signals and Systems");
			subject.add("Electronic Circuits- I ");
			//ec sem 4
			subject.add("Probability and Random Processes");
			subject.add("Electronic Circuits II");
			subject.add("Communication Theory");
			subject.add("Electromagnetic Fields");
			subject.add("Linear Integrated Circuits");
			subject.add("Control System Engineering");
			//ec sem 5
			subject.add("Digital Communication");
			subject.add("Principles of Digital Signal Processing");
			subject.add("Transmission Lines and Wave Guides");
			subject.add("Environmental Science and Engineering");
			subject.add("Microprocessor and Microcontroller");
			//ec sem 6
			subject.add("Principles of Management");
			subject.add("Computer Architecture");
			subject.add("Computer Networks");
			subject.add("VLSI Design");
			subject.add("Antenna and Wave propagation");
			//ec sem 7
			subject.add("RF and Microwave Engineering");
			subject.add("Optical Communication and Networks");
			subject.add("Embedded and Real Time Systems");
			subject.add("Medical Electronics ");
			subject.add("Robotics and Automation ");
			//ec sem 8
			subject.add("Wireless Communication");
			subject.add("Wireless Networks ");
			subject.add("RF System Design");
			subject.add("Ad hoc and Sensors Networks");
			subject.add("Indian Constitution and Society");
			//Elective
			subject.add("Disaster Management");
			subject.add("Data Converters");
			subject.add("Cryptography and Network Security");
			subject.add("Total Quality Management");
			subject.add("Entrepreneurship Development");
			subject.add("Software Project Management");
			subject.add("Human Rights");
			subject.add("Radar and Navigational Aids ");
			subject.add("CMOS Analog IC Design");
			
			//me subjects
			subject.add("Fundamentals of Design");
			subject.add("Mechanical Systems and Manufacturing Considerations in Design");
			subject.add("Design of Fasteners and Joints");
			subject.add("Design of Basic Machine Element");
			subject.add("Design of Springs");
			subject.add("Measurements");
			subject.add("Instruments");
			subject.add("Parameters for Measurement");
			subject.add("Automatic Control Systems");
			subject.add("Application of Control Systems");
			subject.add("Basic Concepts and Isentropic Flows");
			subject.add("Flow Through Duct");
			subject.add("Normal and Oblique Shocks");
			subject.add("Jet Propulsion");
			subject.add("Space Propulsion");
			subject.add("Turning Machines");
			subject.add("Other Basic Machines Gear Cutting Machines");
			subject.add("Automats");
			subject.add("Theory of Metal Cutting");
			subject.add("The Design Process");
			subject.add("Interactive Computer Graphic");
			subject.add("Solid Modelling");
			subject.add("Finite Element Analysis");
			subject.add("Basic Concepts of Measurements");
			subject.add("Linear and Angular Measurements");
			subject.add("Form Measurements");
			subject.add("Laser Metrology");
			subject.add("Advances in Metrology");
			subject.add("Term Project");
			subject.add("Jigs");
			subject.add("Locating and Clamping Devices");
			subject.add("Production Planning and Control");
			subject.add("Part Programming for CNC Machines");
			subject.add("Constructional Features of CNC Machines");
			subject.add("Fixture");
			subject.add("Press Tool");
			subject.add("Term Project");
			subject.add("Conduction");
			subject.add("Radiation");
			subject.add("Convective Heat Transfer");
			subject.add("Phase Change Heat Transfer and Heat Exchangers	");
			subject.add("Basic Principles");
			subject.add("Design & Selection");
			subject.add("Spur Gears");
			subject.add("Components of Environment");
			subject.add("Current Environmental Issues");
			subject.add("Engineering Ethics");
			subject.add("Engineering as Social Experimentation");
			subject.add("Responsibilities and Rights");
			subject.add("Layout of Power Plant");
			subject.add("Sensors and Transducers");
			
			new B().saveSubject(subject);
		
	}
}