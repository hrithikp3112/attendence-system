import java.util.ArrayList;

public class UniversityBranchSemester{
	int universityBranchId;
	int semesterId;

	public int getUniversityBranchId() {
		return universityBranchId;
	}
	public void setUniversityBranchId(int universityBranchId) {
		this.universityBranchId = universityBranchId;
	}
	public int getSemesterId() {
		return semesterId;
	}
	public void setSemesterId(int semesterId) {
		this.semesterId = semesterId;
	}
	
	public UniversityBranchSemester(int universityBranchId, int semesterId) {
		this.universityBranchId = universityBranchId;
		this.semesterId = semesterId;
	}
	public UniversityBranchSemester(){
	
	}

	static ArrayList<UniversityBranchSemester> ubs= new ArrayList();

	public static void addUniBranchSem(){
		for(int i=1;i<=9;i++){
		ubs.add(new UniversityBranchSemester(i,1));
		ubs.add(new UniversityBranchSemester(i,2));
		ubs.add(new UniversityBranchSemester(i,3));
		ubs.add(new UniversityBranchSemester(i,4));
		ubs.add(new UniversityBranchSemester(i,5));
		ubs.add(new UniversityBranchSemester(i,6));
		ubs.add(new UniversityBranchSemester(i,7));
		ubs.add(new UniversityBranchSemester(i,8));
		}

		new B().saveUniBranchSem(ubs);


	}
	
}