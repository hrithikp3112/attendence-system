public class UniversityBranch{
	int universityId;
	int branchId;

	UniversityBranch(int universityId, int branchId){
		this.universityId=universityId;
		this.branchId=branchId;
	}

	public int getUniversityId(){
		return universityId;
	}

	public int getBranchId(){
		return branchId;
	}

	public void setUniversityId(int universityId){
		this.universityId=universityId;
	}	

	public void setBranchId(int branchId){
		this.branchId=branchId;
		
	}

	/*	public String toString(){
			return universityId+","+branchId;
	}*/
}